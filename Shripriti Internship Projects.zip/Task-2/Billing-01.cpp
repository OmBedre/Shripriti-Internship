#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

class Shopping
{
private:
    int productCode;
    float price;
    float discount;
    string productName;

public:
    void displayMainMenu();
    void administratorMenu();
    void buyerMenu();
    void addProduct();
    void modifyProduct();
    void deleteProduct();
    void generateReceipt();
    void displayProductList();
};

void Shopping::displayMainMenu()
{
    int choice;
    string email, password;

    cout << "-----------------------------\n";
    cout << "      Super Market Menu      \n";
    cout << "-----------------------------\n";
    cout << "1) Administrator Login\n";
    cout << "2) Buyer\n";
    cout << "3) Exit\n";
    cout << "Enter your choice: ";
    cin >> choice;

    switch (choice)
    {
    case 1:
    {
        cout << "Administrator Login\n";
        cout << "Enter Email: ";
        cin >> email;
        cout << "Enter Password: ";
        cin >> password;

        if (email == "admin@example.com" && password == "password")
            administratorMenu();
        else
            buyerMenu();

        break;
    }

    case 2:
        buyerMenu();
        break;

    case 3:
        exit(0);
        break;

    default:
        cout << "Invalid choice\n";
    }

    displayMainMenu(); // Recursive call to display the menu again
}

void Shopping::administratorMenu()
{
    int choice;

    cout << "\nAdministrator Menu:\n";
    cout << "1) Add Product\n";
    cout << "2) Modify Product\n";
    cout << "3) Delete Product\n";
    cout << "4) Back to Main Menu\n";
    cout << "Enter your choice: ";
    cin >> choice;

    switch (choice)
    {
    case 1:
        addProduct();
        break;

    case 2:
        modifyProduct();
        break;

    case 3:
        deleteProduct();
        break;

    case 4:
        displayMainMenu();
        break;

    default:
        cout << "Invalid choice\n";
    }

    administratorMenu(); // Recursive call to display the administrator menu again
}

void Shopping::buyerMenu()
{
    int choice;

    cout << "\nBuyer Menu:\n";
    cout << "1) Place the Order\n";
    cout << "2) Return to Main Menu\n";
    cout << "Enter your choice: ";
    cin >> choice;

    switch (choice)
    {
    case 1:
        generateReceipt();
        break;

    case 2:
        displayMainMenu();
        break;

    default:
        cout << "Invalid choice\n";
    }

    buyerMenu(); // Recursive call to display the buyer menu again
}

void Shopping::addProduct()
{
    fstream data;
    int tempCode;
    int token = 0;
    float tempPrice, tempDiscount;
    string tempName;

    cout << "\nAdd New Product:\n";
    cout << "Product Code: ";
    cin >> tempCode;

    data.open("database.txt", ios::in);
    if (!data)
    {
        data.open("database.txt", ios::app | ios::out);
        data << tempCode << " " << tempName << " " << tempPrice << " " << tempDiscount << "\n";
        data.close();
    }
    else
    {
        data >> productCode >> productName >> price >> discount;

        while (!data.eof())
        {
            if (productCode == tempCode)
            {
                token++;
            }
            data >> productCode >> productName >> price >> discount;
        }
        data.close();
    }

    if (token == 1)
    {
        cout << "Product with the same code already exists. Please try again.\n";
        return;
    }
    else
    {
        cout << "Product Name: ";
        cin.ignore(); // Clear the newline character from the buffer
        getline(cin, tempName);
        cout << "Product Price: ";
        cin >> tempPrice;
        cout << "Discount (%): ";
        cin >> tempDiscount;

        data.open("database.txt", ios::app | ios::out);
        data << tempCode << " " << tempName << " " << tempPrice << " " << tempDiscount << "\n";
        data.close();
    }

    cout << "\nProduct Added Successfully!\n";
}

void Shopping::modifyProduct()
{
    fstream data, data1;
    int productKey, tempCode;
    int token = 0;
    float tempPrice, tempDiscount;
    string tempName;

    cout << "\nModify Product:\n";
    cout << "Enter Product Code to Modify: ";
    cin >> productKey;

    data.open("database.txt", ios::in);
    if (!data)
    {
        cout << "File doesn't exist.\n";
        return;
    }
    else
    {
        data1.open("temp_database.txt", ios::app | ios::out);
        data >> productCode >> productName >> price >> discount;

        while (!data.eof())
        {
            if (productKey == productCode)
            {
                cout << "\nProduct New Code: ";
                cin >> tempCode;
                cout << "New Product Name: ";
                cin.ignore();
                getline(cin, tempName);
                cout << "New Product Price: ";
                cin >> tempPrice;
                cout << "New Discount (%): ";
                cin >> tempDiscount;
                data1 << tempCode << " " << tempName << " " << tempPrice << " " << tempDiscount << "\n";
                cout << "\nProduct Record Edited.\n";
                token++;
            }
            else
            {
                data1 << productCode << " " << productName << " " << price << " " << discount << "\n";
            }
            data >> productCode >> productName >> price >> discount;
        }
        data.close();
        data1.close();

        remove("database.txt");
        rename("temp_database.txt", "database.txt");

        if (token == 0)
        {
            cout << "\nProduct not found.\n";
        }
    }
}

void Shopping::deleteProduct()
{
    fstream data, data1;
    int productKey;
    int token = 0;

    cout << "\nDelete Product:\n";
    cout << "Enter Product Code to Delete: ";
    cin >> productKey;

    data.open("database.txt", ios::in);
    if (!data)
    {
        cout << "File doesn't exist.\n";
        return;
    }
    else
    {
        data1.open("temp_database.txt", ios::app | ios::out);
        data >> productCode >> productName >> price >> discount;

        while (!data.eof())
        {
            if (productCode == productKey)
            {
                cout << "\nProduct Deleted Successfully.\n";
                token++;
            }
            else
            {
                data1 << productCode << " " << productName << " " << price << " " << discount << "\n";
            }
            data >> productCode >> productName >> price >> discount;
        }
        data.close();
        data1.close();

        remove("database.txt");
        rename("temp_database.txt", "database.txt");

        if (token == 0)
        {
            cout << "\nProduct not found.\n";
        }
    }
}

void Shopping::displayProductList()
{
    fstream data;
    data.open("database.txt", ios::in);

    if (!data)
    {
        cout << "\nEmpty database.\n";
    }
    else
    {
        cout << "\n-------------------------------------------\n";
        cout << "Product Code\t\tProduct Name\t\tProduct Price\n";
        cout << "-------------------------------------------\n";
        data >> productCode >> productName >> price >> discount;

        while (!data.eof())
        {
            cout << productCode << "\t\t\t" << productName << "\t\t\t" << price << "\n";
            data >> productCode >> productName >> price >> discount;
        }

        data.close();
    }
}

void Shopping::generateReceipt()
{
    fstream data;
    int productCodes[100];
    int productQuantities[100];
    char choice;
    int count = 0;
    float totalAmount = 0;

    cout << "\n-------------------RECEIPT-------------------\n";
    displayProductList();
    cout << "\n----------------------------------------------\n";
    cout << "Please place your order:\n";

    do
    {
        cout << "Enter Product Code: ";
        cin >> productCodes[count];
        cout << "Enter Product Quantity: ";
        cin >> productQuantities[count];

        for (int i = 0; i < count; i++)
        {
            if (productCodes[count] == productCodes[i])
            {
                cout << "Duplicate product code. Please try again!\n";
                return;
            }
        }

        count++;
        cout << "\nDo you want to buy another product? (y/n): ";
        cin >> choice;

    } while (choice == 'y');

    cout << "\n-------------------RECEIPT-------------------\n";
    cout << "Product Code\tProduct Quantity\tProduct Price\tAmount\n";

    data.open("database.txt", ios::in);
    if (!data)
    {
        cout << "\nEmpty database.\n";
    }
    else
    {
        data >> productCode >> productName >> price >> discount;

        for (int i = 0; i < count; i++)
        {
            while (!data.eof())
            {
                if (productCodes[i] == productCode)
                {
                    float amount = price * productQuantities[i];
                    totalAmount += amount;
                    cout << productCode << "\t\t" << productQuantities[i] << "\t\t\t" << price << "\t\t" << amount << "\n";
                }
                data >> productCode >> productName >> price >> discount;
            }

            data.clear();     // clear the end-of-file flag
            data.seekg(0, ios::beg); // reset file pointer to the beginning
        }
        data.close();
    }

    cout << "----------------------------------------------\n";
    cout << "Total Amount: " << totalAmount << "\n";
}

int main()
{
    Shopping s;
    s.displayMainMenu();

    return 0;
}


